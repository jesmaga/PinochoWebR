/**
 * @license Highcharts Gantt JS v8.2.2 (2020-10-22)
 * @module highcharts/modules/static-scale
 * @requires highcharts
 *
 * StaticScale
 *
 * (c) 2016-2019 Torstein Honsi, Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/StaticScale.js';
